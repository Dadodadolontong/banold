// Copyright (c) 2017, BAN and contributors
// For license information, please see license.txt

frappe.ui.form.on('Proses BAN', {
	refresh: function(frm) {

	}
});
