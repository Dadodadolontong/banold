import frappe
from erpnext.stock.stock_ledger import get_previous_sle

@frappe.whitelist()

def submit_inv():
    print("Hello there")
    list_inv = frappe.get_list('Sales Invoice', filters = [['docstatus','=',0],["posting_date",">=","01-04-2018"]], order_by="posting_date")
    i = 0
    for l in list_inv:
        i += 1
        inv = frappe.get_doc('Sales Invoice',l.name)
	balance = get_previous_sle({"item_code":"FG-ALNPKT-00","warehouse":"Finished Goods - BAN","posting_date":l.posting_date,"posting_time":l.posting_time})
	print("{0} Invoice Name {1} Current balance: {2}".format(i,l.name,balance))
        for li in inv.get('items'):
            print("   Warehouse: {2} Batch: {0} Qty: {1}".format(li.batch_no,li.qty, li.warehouse))
        inv.submit()
        frappe.db.commit()
