import frappe, erpnext

@frappe.whitelist()

def explode(sales_invoice, item_code, qty, price)
    si = frappe.get_doc("Sales Invoice",sales_invoice)
    
    batch_avail = frappe.db.sql("""select batch_no, bt.expiry_date, warehouse, sum(actual_qty)i as onhand from `tabStock Ledger Entry` le join tabBatch bt on bt.name = le.batch_no where item_code = '{}' group by batch_no, bt.expiry_date, warehouse having sum(actual_qty) <> 0 order by bt.expiry_date""".format(item_code), as_dict=1) 

    item = frappe.get_doc("Item",item_code);
    run_sum = qty
    for batch in batch_avail:
 	qty = min(flt(batch['onhand']),run_sum);
          
        si.append("items", {
                    "item_code":item_code,
		    "item_name":item.item_name,
		    "description":item.item_description,
		    "qty": qty,
                    "batch_no": batch['batch_no'],
                    "warehouse": batch['warehouse'],
		    "stock_uom":item.sales_uom, 
		    "rate": price
	})

        si.set_missing_values();
        si.save();
        
        run_sum-=qty;
        if (run_sum<=0):
           break
